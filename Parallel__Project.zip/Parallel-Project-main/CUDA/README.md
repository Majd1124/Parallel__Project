# simple_cnn

simple_cnn is ment to be an easy to read and easy to use convolutional neural network library.

simple_cnn is written in a mostly C-like manner behind the scenes, doesnt use virtual classes and avoids using std where its possible so that it is easier to convert to CUDA code when needed.


Example use on handwritten digit recognition (Youtube Video):

[![Youtube Video](https://img.youtube.com/vi/afLUb6lFTCk/0.jpg)](https://www.youtube.com/watch?v=afLUb6lFTCk)

# Building

On linux, run make.


MNIST digits taken from http://yann.lecun.com/exdb/mnist/
