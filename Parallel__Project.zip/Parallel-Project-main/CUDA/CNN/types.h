#pragma once

enum class layer_type
{
	conv,
	fc,
	relu,
	pool,
	dropout_layer
};