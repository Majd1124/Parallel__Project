#pragma once
struct point_t
{
	int x, y, z;
};
using tdsize = point_t;